package com.springboot.previred.template;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "valores")
public class ValorUf implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JacksonXmlProperty
	private String inicio;

	@JacksonXmlProperty
	private String fin;
	@JacksonXmlElementWrapper(localName = "UFs", useWrapping = true)
	private List<UfDetalle> UFs;

	public String getInicio() {
		return inicio;
	}

	public void setInicio(String inicio) {
		this.inicio = inicio;
	}

	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public List<UfDetalle> getUFs() {
		return UFs;
	}

	public void setUFs(List<UfDetalle> uFs) {
		UFs = uFs;
	}
}
