package com.springboot.previred.controllers;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.previred.interfaces.IControllerOutput;
import com.springboot.previred.template.ValorUf;

@RestController
@RequestMapping("/api")
public class Controller {

	@Autowired
	IControllerOutput controllerOutputService;
	private static final Logger log = LoggerFactory.getLogger(Controller.class);
	
	@GetMapping("/valores/json")
	public void getUfValuesAsJson(HttpServletResponse response) {
		String fileName = "valores.json";
		response.setContentType("application/json");
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");

		try {
			controllerOutputService.getValoresAsJson(response.getWriter());
		} catch (IOException e) {
			log.error("Error: " + e.getCause().getMessage());
		}

	}

	@GetMapping(value = "/valores/xml", produces=MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<ValorUf> getUfValuesAsXml() {
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + "valores.xml" + "\"");

		return new ResponseEntity<ValorUf>(controllerOutputService.getValoresAsXml(), headers, HttpStatus.OK);
	}

	@GetMapping("/valores/csv")
	public void getUfValoresAsCsv(HttpServletResponse response) {
		String fileName = "valores.csv";
		response.setContentType("text/csv");
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");

		try {
			controllerOutputService.getUfValuesAsCsv(response.getWriter());
		} catch (IOException e) {
			log.error("Error: " + e.getCause().getMessage());
		}

	}
}
