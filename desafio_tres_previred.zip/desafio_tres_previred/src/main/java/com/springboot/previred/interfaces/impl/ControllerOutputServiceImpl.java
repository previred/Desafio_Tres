package com.springboot.previred.interfaces.impl;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.previred.desafio.tres.uf.DatosUf;
import com.previred.desafio.tres.uf.Valores;
import com.previred.desafio.tres.uf.vo.Uf;
import com.previred.desafio.tres.uf.vo.Ufs;
import com.springboot.previred.interfaces.IControllerOutput;
import com.springboot.previred.template.UfDetalle;
import com.springboot.previred.template.ValorUf;

@Service
public class ControllerOutputServiceImpl implements IControllerOutput {

	private static SimpleDateFormat DATE_FORMAT;
	protected static final Valores valores = new Valores();
	private Ufs ufs;
	private Date inicio;
	private Date fin;
	private Date fecha;

	@PostConstruct
	private void postConstruct() {
		DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault(Locale.Category.FORMAT));
		ufs = valores.getRango();
		inicio = ufs.getInicio();
		fin = ufs.getFin();
		completeUfValues();
	}

	protected void completeUfValues() {
		List<Date> ufDates = getUfdatesFromValores();
		List<Uf> ufListFromDatosUf = getUfListFromDatosUf();

		for (this.fecha = this.inicio; this.fecha
				.before(DateUtils.addDays(this.fin, 1)); this.fecha = DateUtils.addDays(this.fecha, 1)) {
			if (!ufDates.contains(this.fecha)) {
				Uf ufToAdd = ufListFromDatosUf.stream().filter(uf -> uf.getFecha().compareTo(this.fecha) == 0)
						.findFirst().orElse(null);
				if (ufToAdd != null) {
					this.ufs.getUfs().add(ufToAdd);
				}
			}
		}

	}

	protected List<Date> getUfdatesFromValores() {

		return this.ufs.getUfs().stream().map(uf -> uf.getFecha()).collect(Collectors.toList());
	}

	protected List<Uf> getUfListFromDatosUf() {

		return DatosUf.getInstance().getUfs(this.inicio, this.fin);
	}

	protected List<Uf> getUfListFullAndSorted() {
		List<Uf> ufList = this.ufs.getUfs().stream().collect(Collectors.toList());
		Collections.sort(ufList, (Uf o1, Uf o2) -> o1.getFecha().compareTo(o2.getFecha()));
		return ufList;
	}

	@Override
	public void getValoresAsJson(PrintWriter writer) {
		List<Uf> sortedUfList = this.getUfListFullAndSorted();
		List<UfDetalle> ufJsonList = sortedUfList.stream().map(uf -> {
			UfDetalle ufJson = new UfDetalle();
			ufJson.setFecha(DATE_FORMAT.format(uf.getFecha()));
			ufJson.setDato(uf.getValor().toString());
			return ufJson;
		}).collect(Collectors.toList());

		ValorUf datoUfJson = new ValorUf();
		datoUfJson.setInicio(DATE_FORMAT.format(this.inicio));
		datoUfJson.setFin(DATE_FORMAT.format(this.fin));
		datoUfJson.setUFs(ufJsonList);

		Gson gson = new Gson();
		gson.toJson(datoUfJson, writer);
	}

	@Override
	public void getUfValuesAsCsv(PrintWriter writer) {
		List<Uf> sortedUfList = this.getUfListFullAndSorted();

		writer.write("1; " + DATE_FORMAT.format(this.inicio) + "; " + DATE_FORMAT.format(this.fin) + "\n");

		for (Uf uf : sortedUfList) {
			writer.write("2; " + DATE_FORMAT.format(uf.getFecha()) + "; " + uf.getValor() + "\n");
		}

	}

	@Override
	public ValorUf getValoresAsXml() {
		List<Uf> sortedUfList = this.getUfListFullAndSorted();
		List<UfDetalle> ufJsonList = sortedUfList.stream().map(uf -> {
			UfDetalle ufJson = new UfDetalle();
			ufJson.setFecha(DATE_FORMAT.format(uf.getFecha()));
			ufJson.setDato(uf.getValor().toString());
			return ufJson;
		}).collect(Collectors.toList());

		ValorUf datoUfJson = new ValorUf();
		datoUfJson.setInicio(DATE_FORMAT.format(this.inicio));
		datoUfJson.setFin(DATE_FORMAT.format(this.fin));
		datoUfJson.setUFs(ufJsonList);

		return datoUfJson;
	}

}
