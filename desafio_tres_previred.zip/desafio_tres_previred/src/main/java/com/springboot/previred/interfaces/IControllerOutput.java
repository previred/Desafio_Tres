package com.springboot.previred.interfaces;

import java.io.PrintWriter;

import com.springboot.previred.template.ValorUf;

public interface IControllerOutput {
	public void getValoresAsJson(PrintWriter writer);

	public ValorUf getValoresAsXml();

	public void getUfValuesAsCsv(PrintWriter writer);
}
