package com.springboot.previred;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioTresPreviredApplicationTests {

	
	@Test
	void test() {
	}
}
